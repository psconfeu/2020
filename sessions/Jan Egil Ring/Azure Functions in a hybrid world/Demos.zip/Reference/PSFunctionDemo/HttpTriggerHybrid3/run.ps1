using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

$null = Set-AzContext -Subscription 380d994a-e9b5-4648-ab8b-815e2ef18a2b

$Secret = Get-AzKeyVaultSecret -VaultName psconfeu2020 -Name RBKAutomationRSAKey | Select-Object -ExpandProperty SecretValueText

$RSAKey = [System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String($Secret))

$RBKAutomationPrivateKey = Join-Path -Path $env:temp -ChildPath id_rsa_rbk_automation
$RSAKey | Set-Content -Path $RBKAutomationPrivateKey

Write-Output "Path to SSH key: $RBKAutomationPrivateKey"
Write-Output "SSH key:"

#Get-Content $RBKAutomationPrivateKey

#$RemoteResponse = Invoke-Command -HostName centos7.rbk.ad -UserName rbkautomation -KeyFilePath $RBKAutomationPrivateKey -ScriptBlock {$PSVersionTable.PSVersion.ToString()}

$UserName = "administrator"
$securedPassword = ConvertTo-SecureString  $Env:RBKAdminPassword -AsPlainText -Force
$Credential = [System.management.automation.pscredential]::new($UserName, $SecuredPassword)

<#
$RemoteResponse = Invoke-Command -ComputerName MGMT-AZ-01.rbk.ad `
               -Credential $Credential `
               -Port 5986 `
               -UseSSL `
               -ScriptBlock {"Hello from PowerShell $($PSVersionTable.PSVersion.ToString()) on $env:COMPUTERNAME"} `
               -SessionOption (New-PSSessionOption -SkipCACheck -SkipCNCheck) `
               -ConfigurationName PowerShell.7.0.1
#>

Copy-Item -ToSession $session -Path $RBKAutomationPrivateKey -Destination C:\Windows\Temp

Invoke-Command -Session $session -ScriptBlock {

    $RBKAutomationPrivateKey = 'C:\Windows\Temp\id_rsa_rbk_automation'

    Invoke-Command -HostName centos7.rbk.ad -UserName rbkautomation -KeyFilePath $RBKAutomationPrivateKey -ScriptBlock {"Hello from PowerShell $($PSVersionTable.PSVersion.ToString()) on $(hostname)"}

    Remove-Item $RBKAutomationPrivateKey
}

# Interact with query parameters or the body of the request.
$name = $Request.Query.Name
if (-not $name) {
    $name = $Request.Body.Name
}

if ($name) {
    $status = [HttpStatusCode]::OK
    $body = "Hello $name - Remote response: $RemoteResponse"
}
else {
    $status = [HttpStatusCode]::BadRequest
    $body = "Please pass a name on the query string or in the request body."
}

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = $status
    Body = $body
})
