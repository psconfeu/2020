using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

$Service = $Request.Query.Name

# Note that RBKAdminPassword is a function app setting, so I can access it as $env:ContosoUserPassword.
$UserName = "Administrator"
$securedPassword = ConvertTo-SecureString  $Env:RBKAdminPassword -AsPlainText -Force
$Credential = [System.management.automation.pscredential]::new($UserName, $SecuredPassword)

# This is the name of the hybrid connection Endpoint.
$HybridEndpoint = "MGMT-JR-02.rbk.ad"

$Script = {
    Param(
        [Parameter(Mandatory=$True)]
        [String] $Service
    )
    Get-Service $using:Service
}

Write-Output "Running command via Invoke-Command"
$output = Invoke-Command -ComputerName $HybridEndpoint `
               -Credential $Credential `
               -Port 5986 `
               -UseSSL `
               -ScriptBlock $Script `
               -ArgumentList "*" `
               -SessionOption (New-PSSessionOption -SkipCACheck)

               $status = [HttpStatusCode]::OK
               $body = "Status for service $Service is $($output.Status)"

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = $status
    Body = $body
})