using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

# Note that RBKAdminPassword is a function app setting, so I can access it as $env:ContosoUserPassword.
$UserName = "Administrator"
$securedPassword = ConvertTo-SecureString  $Env:RBKAdminPassword -AsPlainText -Force
$Credential = [System.management.automation.pscredential]::new($UserName, $SecuredPassword)


$Output = Invoke-Command -ComputerName HPV-JR-02.rbk.ad `
               -Credential $Credential `
               -Port 5986 `
               -UseSSL `
               -ScriptBlock {Get-VM | Select-Object Name,Status} `
                            -SessionOption (New-PSSessionOption -SkipCACheck -SkipCNCheck)

                            $Output

               $status = [HttpStatusCode]::OK
               $body = "Got $($output.Count) VMs from on-prem Hyper-V host HPV-JR-02 "

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = $status
    Body = $body
})