using namespace System.Net

# Input bindings are passed in via param block.
param($Request, $TriggerMetadata)

# Write to the Azure Functions log stream.
Write-Host "PowerShell HTTP trigger function processed a request."

$null = Set-AzContext -Subscription 380d994a-e9b5-4648-ab8b-815e2ef18a2b

# CimSession
$UserName = "Administrator"
$securedPassword = ConvertTo-SecureString  $Env:RBKAdminPassword -AsPlainText -Force
$Credential = [System.management.automation.pscredential]::new($UserName, $SecuredPassword)

$CimSession = New-CimSession -Credential $Credential -ComputerName MGMT-AZ-01.rbk.ad
Get-NetAdapter -CimSession $CimSession

# Custom session configuration with domain user specified as the RunAs account
Invoke-Command -ComputerName MGMT-AZ-01.rbk.ad -Credential $Credential -ScriptBlock {dir \\hpv-jr-02\d$\Hyper-V}

# Interact with query parameters or the body of the request.
$name = $Request.Query.Name
if (-not $name) {
    $name = $Request.Body.Name
}

if ($name) {
    $status = [HttpStatusCode]::OK
    $body = "Hello $name - Remote response: $RemoteResponse"
}
else {
    $status = [HttpStatusCode]::BadRequest
    $body = "Please pass a name on the query string or in the request body."
}

# Associate values to output bindings by calling 'Push-OutputBinding'.
Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
    StatusCode = $status
    Body = $body
})
