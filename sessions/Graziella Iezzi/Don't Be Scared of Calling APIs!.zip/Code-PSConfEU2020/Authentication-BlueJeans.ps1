# Authentication in BlueJeans with Bearer Token generated dynamically
# Retrieve secrets from your safe place!!!
$clientID = Get-Secret BlueJeans-ClientID -AsPlainText
$clientSecret = Get-Secret BlueJeans-ClientSecret -AsPlainText 

# Retrieve the token
$header1 = @{
    'Content-Type' = 'application/json'
    'accept' = 'application/json'
}

$method1 = 'POST'
$uri1 = 'https://api.bluejeans.com/oauth2/token?Client'
$body1 = @"
{"grant_type":"client_credentials","client_id": ${clientID},"client_secret": ${clientSecret}}
"@
$token = (Invoke-RestMethod -Method $method1 -Uri $uri1 -Headers $header1 -Body $body1).access_token

# Test your authentication

# Finally use the token to get the user profile
$userEmail = 'greg.house@domain.com'
$method2 = 'GET'
$uri2 = "https://api.bluejeans.com/v1/enterprise/<your enterprise ID>/users?access_token=${token}&emailId=${userEmail}"

$userProfile = Invoke-RestMethod -Method $method2 -Uri $uri2 

