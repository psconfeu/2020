# Authentication in Slack with Bearer Token generated from the application
# Retrieve the token from your safe place!!
$token = Get-Secret Slack -AsPlainText
# Authorization value has to be prefixed by Bearer following by the encoded credentials
$bearerTokenValue = "Bearer $token"
$headers = @{
    Authorization = $bearerTokenValue
}


# Test your authentication

$method = 'GET'
$uri = 'https://api.slack.com/scim/v1/Users'

# Get the total amount of users in Slack
$result = (Invoke-RestMethod -Method $method -Uri $uri -Headers $headers).totalResults

# Response: 

# totalResults : 1234
# itemsPerPage : 1000
# startIndex   : 1
# schemas      : {urn:scim:schemas:core:1.0}
# Resources    : {@{schemas=System.Object[]; id=WTE0G3JRG; externalId=; meta=; userName=grazi; nickName=grazi; name=; displayName=Graziella Iezzi;
#              profileUrl=https://<your Slack doamin>/team/grazi; title=; timezone=Europe/Amsterdam; active=True; emails=System.Object[];       
#              photos=System.Object[]; groups=System.Object[]}, …}
