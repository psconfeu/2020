# Seek pagination - Slack

#region - Example allowing an high count value

$method = 'GET'
$uri = 'https://api.slack.com/scim/v1/Users?count=100000'

$listUsers = Invoke-RestMethod -Method $method -Uri $uri -Headers $headers

# Response:

# totalResults : 1234
# itemsPerPage : 1234
# schemas      : {urn:scim:schemas:core:1.0}
# Resources    : {@{schemas=System.Object[]; id=WTE0G3JRG; externalId=; meta=; userName=grazi; nickName=grazi; name=; displayName=Graziella Iezzi;
#              profileUrl=https://<your Slack doamin>/team/grazi; title=; timezone=Europe/Amsterdam; active=True; emails=System.Object[];       
#              photos=System.Object[]; groups=System.Object[]}, …}

#endregion

#region - Example allowing a fixed amount of results per page and managing cursors is needed

# Define the array that will contain all the results
$listUsers = @()
$startIndex = 1

# Get the total amount of users
$method = 'GET'
$uri = "https://api.slack.com/scim/v1/Users"

$usersObj = Invoke-RestMethod -Method $method -Uri $uri -Headers $headers
$totalResults = $usersObj.totalResults
# divide it by 1000 to get how many pages we need to loop into
$amountOfPages = [System.Math]::Floor(($totalResults / 1000))

# call the API for each page updating the counter index
for ($i = 0; $i -le $amountOfPages; $i++) {
    $usersObj = Invoke-RestMethod -Method $method -Uri "$uri\?count=1000&startIndex=$startIndex" -Headers $headers
    $listUsers += $usersObj
    $startIndex += 1000
}

# Response: 

# totalResults : 3450
# itemsPerPage : 1000
# startIndex   : 1
# schemas      : {urn:scim:schemas:core:1.0}
# Resources    : {@{schemas=System.Object[]; id=WTE0G3JRG; externalId=; meta=; userName=grazi; nickName=grazi; name=; displayName=Graziella Iezzi;
#              profileUrl=https://<your Slack doamin>/team/grazi; title=; timezone=Europe/Amsterdam; active=True; emails=System.Object[];       
#              photos=System.Object[]; groups=System.Object[]}, …}
#endregion