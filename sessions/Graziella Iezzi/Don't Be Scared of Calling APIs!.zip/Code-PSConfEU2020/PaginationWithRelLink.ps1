# Pagination with relation link returned in response header - GitHub

# Get the first 4 pages of issues in the powershell repository
$method = 'GET'
$uri = 'https://api.github.com/repos/powershell/powershell/issues'
$issuesList = Invoke-RestMethod -Method $method -uri $Uri -FollowRelLink -MaximumFollowRelLink 4

# It returns the amount of pages
$issuesList.Count
# It contains the actual data for each call we made
$issuesList[0].Count
$issuesList[3].Count
# It contains the info from 1 issue
$issuesList[0][3]

# Where does FollowRelLink takes the next link?
$issuesList = Invoke-RestMethod -Method $method -uri $Uri -FollowRelLink -MaximumFollowRelLink 4 -ResponseHeadersVariable abc
$abc
$abc.Link
