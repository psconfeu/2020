# Deprovision Users from Trello from a CSV

# Load the CSV
$fullUsersList = Import-Csv -Path C:\Users\grazi\Trello-Users-List.csv 

#region - Check what users are disabled in Active Directory
#region - Example 1

$usersWithADStatus = foreach ( $user in $fullUsersList ){ 
            $email = $user.Email
            $idMember = $user.idMember
            [PSCustomObject]@{
                Email = $email
                idMember = $idMember
                Enabled = $(Get-ADUser -Filter {mail -eq $email} -Properties Enabled).Enabled
            }
}
#endregion

#region - Example 2
$usersWithADStatus = foreach ( $user in $fullUsersList ){ 
    [PSCustomObject]@{
        Email = $user.Email
        idMember = $user.idMember
        Enabled = $(Get-ADUser -Filter {mail -eq $($user.Email)} -Properties Enabled).Enabled
    }
}
#endregion

# Export the result in a CSV for reference
$usersWithADStatus | Export-Csv -Path C:\Users\grazi\Trello-Users-With-AD-Status.csv -NoTypeInformation -UseQuotes Never
# Get only the users disabled in Active Directory
#region - Example1
$usersToDisable = Import-Csv -Path C:\Users\grazi\Trello-Users-With-AD-Status.csv | Where-Object {$_.Enabled -eq 'False'}
#endregion

#region - Exmaple 2
$usersToDisable = $usersWithADStatus | Where-Object {$_.Enabled -eq 'False'}
#endregion

#endregion

#region - Disable users in Trello
# To get the applicaiton key https://trello.com/app-key
$appKey = Get-Secret Trello-AppKey -AsPlainText
# To get the organization token https://trello.com/enterprise/<your organization id>/token
$token = Get-Secret Trello-Token -AsPlainText

$method = 'PUT'
$uri = "https://api.trello.com/1/enterprises/<your organization id>/members"
# Call the endopoint to disable the accounts for each user in the list
#region - Example 1
$usersDisabled = foreach ($user in $usersToDisable){
            $email = $user.Email
            $idMember = $user.idMember
            $enabled = $user.Enabled
            $response = Invoke-RestMethod -Method $method -Uri "$uri/$idMember/deactivated?value=true&key=$appKey&token=$token" 
            [PSCustomObject]@{
                Email = $email
                idMember = $idMember
                Enabled = $enabled
                Status = $response.StatusCode
            }
}
#endregion

#region - Example 2
$usersDisabled = foreach ($user in $usersToDisable){
    $response = Invoke-RestMethod -Method $method -Uri "$uri/$($user.idMember)/deactivated?value=true&key=$appKey&token=$token" 
    [PSCustomObject]@{
        Email = $user.Email
        idMember = $user.idMember
        Enabled = $user.Enabled
        Status = $response.StatusCode
    }
}
#endregion

# Export the result in a CSV for reference
$usersDisabled | Export-Csv -Path C:\Users\grazi\Trello-People-Disabled.csv -NoTypeInformation -UseQuotes Never

#endregion