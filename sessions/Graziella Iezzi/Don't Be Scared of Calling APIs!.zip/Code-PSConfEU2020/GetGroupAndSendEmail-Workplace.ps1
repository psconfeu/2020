# Get the members of a Workplace group and send the result by email

#region - Get data from Workplace

# Retrieve the token from your safe place!!
$apiToken =  Get-Secret Workplace-Token -AsPlainText
# Set GroupID
$groupId = '123456789098765'
# Preparing call attributes
$method = 'GET'
$uri = "https://graph.workplace.com/$groupId/members?fields=first_name,last_name,email,joined,department&access_token=$apiToken"
# Call the endpoint once to get the first set of data and the next paging link
$membersObj = Invoke-RestMethod -Method $method -Uri $uri
$membersList = $membersObj.data
# run until a next link is found in every endpoint called
while ($membersObj.paging.next) {
    $membersObj = Invoke-RestMethod -Uri $membersObj.paging.next
    $membersList += $membersObj.data
}

# PS C:\Users\grazi> $membersList

# email      : grazi@domain.com
# first_name : Graziella
# last_name  : Iezzi
# id         : 123456789098765       
# joined     : 1590583986

# email      : greg.house@domain.com
# first_name : Gregory
# last_name  : House
# id         : 138475937465748
# joined     : 1590574454

#endregion

#region - Convert the date from EPOCH to a readable format
# Defining the array that will contain the final results
$finalMembersData = @()
# foreach element found get the joiner in the last 7 days and convert teh date from EPOCH to a readable format
foreach ($elem in $membersList){
    # Define a DateTime object with a readable format
    $date = New-Object -Type DateTime -ArgumentList 1970, 1, 1, 0, 0, 0, 0 
    # Convert the EPOCH date to the readable format 
    $joined = $date.AddSeconds($elem.joined) # '1590621701'
    if ($joined -gt (get-date).AddDays(-7)){
        $finalMembersData += [PSCustomObject]@{ 
                                    first_name = $elem.first_name
                                    last_name = $elem.last_name
                                    email = $elem.email
                                    joined = $joined
                                }
    }
}
#endregion

#region - Export the data in a file to attach to the email
$filePath = 'C:\Users\grazi\Members-List-XYZGroup.csv'
$finalMembersData | Export-Csv -Path $filePath -NoTypeInformation -UseQuotes Never
#endregion

#region - Send the email
if($finalMembersData.Count -gt 0){
    $smtpServer = "smtp.domain.com"
    $fromAddress = "noreply@domain.com"
    $toAddress = "Sad Joey <sad.joey@domain.com>, Grazi <grazi@domain.com>"
    $emailSubject = "Group XYZ members list"
    $body = "Please find attached the list of members of the 'XYZ' group"

    Send-MailMessage -smtpServer $smtpServer -from $fromAddress -to $toAddress -subject $emailSubject -body $body -bodyashtml -Attachments $filePath  
}
#endregion