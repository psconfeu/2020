# Pagination with cursor in response - Workplace

$apiToken =  Get-Secret Workplace-Token -AsPlainText
$method = 'GET'
$uri = "https://graph.workplace.com/community/members?access_token=$apiToken"
$membersObj = Invoke-RestMethod -Method $method -Uri $uri
$membersList = $membersObj.data

# run until a next link is found in every endpoint called
while ($membersObj.paging.next) {
    $membersObj = Invoke-RestMethod -Uri $membersObj.paging.next
    $membersList += $membersObj.data
}

# Results:

# > $membersObj | Format-List

# data		:	{@{name=Graziella Iezzi; id=123456789098765; administrator=False}, @{name=Greg House; id=987654321234567; administrator=True},  …}
# paging	: 	@{cursors=; 
#               next=https://graph.workplace.com/v3.0/<organization ID>/members?access_token=<api token>&
#               limit=25&
#               after=QVFIUnJWajY5T2Rza3BvQmNHb2hpYm9QUmh6SFB5MGJSbVBqOEpadlZAIMVQVFIUnJWajY5T2Rza3BvQmNHb2hpYm9QUmh6SFB5MGJSbVBqOEpadlZAIMV}
