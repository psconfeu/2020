# Authentication in Trello with Application Key and Token generated from the application
# To get the application key https://trello.com/app-key
$appKey = Get-Secret Trello-AppKey -AsPlainText
# To get the organization token https://trello.com/enterprise/<your organization name>/token
$token = Get-Secret Trello-Token -AsPlainText

$method = 'GET'
$uri = "https://api.trello.com/1/members/me/boards?key=$appKey&token=$token"

# Test your authentication

# Get the lsit of boards you have
$boardsObj = Invoke-WebRequest -Method $method -Uri $uri
# Content is in JSON format you need to convert it to an object before you can navigate properly
$list = $boardsObj.Content | ConvertFrom-Json
$list.name
