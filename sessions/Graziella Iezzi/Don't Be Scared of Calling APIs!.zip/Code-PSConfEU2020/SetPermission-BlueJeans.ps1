# Set managing event permission - BlueJeans

#region Get BlueJeans userID 
$userEmail = 'greg.house@domain.com'
$method = 'GET'
$uri = "https://api.bluejeans.com/v1/enterprise/<organization ID>/users?access_token=${token}&emailId=${userEmail}"
$userProfile = Invoke-RestMethod -Method $method -Uri $uri 
$userID = $userProfile[0].users.id

# PS C:\Users\grazi\BlueJeans> $userProfile

# count users
# ----- -----
#     1 {@{id=1234567; uri=/v1/user/1234567}}

# PS C:\Users\giezzi\RIVER\Work\BlueJeans> $userProfile[0].users.id
# 1234567
#endregion

#region Set Managing Event Permission

$method = 'PUT'
$uri = "https://api.bluejeans.com/v1/user/${userID}/featurepolicies/any_to_many?access_token=${token}"
$header = @{
    'Content-Type' = 'application/json'
    'accept' = 'application/json'
}
$body = @"
{"name":"any_to_many","choice": true}
"@

$res = Invoke-RestMethod -Method $method -Uri $uri -Headers $header -Body $body 

# PS C:\Users\grazi\BlueJeans> $res

# id                 : 6911609
# name               : any_to_many
# choice             : True
# billable           : False
# childrenCanChoose  : True
# ownerType          : USER
# ownerId            : 1234567
# affecteeId         : 1234567
# billingDefault     : 0
# affecteeType       : USER
# useChildrensChoice : True
# lastModified       : 1590679507131

#endregion