# Authentication in Jira Server/Data Center with Basic Authentication
# Retrieve the token from your safe place!!
$username = 'grazi@domain.com'
$password = Get-Secret Jira -AsPlainText
# Create a username and password pair
$pair = "$($username):$($password)" 
# Encode the pair to Base64 string
$encodedCreds = [System.Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($pair))
# Authorization value has to be prefixed by Basic following by the encoded credentials
$basicAuthValue = "Basic $encodedCreds"
$headers = @{
    Authorization = $basicAuthValue
}

# Test your authentication
$method = 'GET'
$uri = 'https://<your Jira Base URL>/rest/api/2/issue/ABC-123' 

$result = Invoke-RestMethod -Uri $uri -Method $method -Headers $headers 

# result in "Jira-Ticket-Result.json"